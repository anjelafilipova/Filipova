﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sales
{

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtdescount_TextChanged(object sender, EventArgs e)
        {

        }
        List<double> listdiscount = new List<double>();
        List<double> listvalue = new List<double>();
        private void btnTotal_Click(object sender, EventArgs e)
        {
            
            try
            {
                if (txtprice.Text == "")
                {
                    throw new MyException ("Моля, попълнете стойност в поле ед.цена!");
                }
                else if (Convert.ToInt32(txtprice.Text) < 0)
                {
                    throw new MyException ("Моля, попълнете Положителна стойност в поле ед.цена!");
                }
            }
            catch (System.FormatException)
            {
                throw new MyException ("Моля, въведете валидно число в поле ед.цена!");
            }
            catch (MyException ee)
            {
                throw new MyException(ee.ToString());
            }

            double discount = 0;
            label9.Visible = true;
            dateTimePicker1.Enabled = false;
            cm.Enabled = false;
            double ValueSales = (Convert.ToDouble(txtprice.Text)) * (Convert.ToDouble(txtQnt.Text));
            if (ValueSales > 100)
            {
                discount = (0.1 * (ValueSales));
                ValueSales -= discount;
                label4.ForeColor = Color.Red;


            }
            else
            {
                             
                label4.ForeColor = Color.Black;

            }
            txtvalue.Text = ValueSales.ToString();
            txtdiscount.Text = discount.ToString();
            listdiscount.Add(discount);
            listvalue.Add(ValueSales);
            btnTotal.Enabled = false;
            btnNewSales.Enabled = true;
        }

        private void btnNewSales_Click(object sender, EventArgs e)
        {
            
            btnNewSales.Enabled = false;
            btnTotal.Enabled = true;
            cb_item.ResetText();
            txtprice.Clear();
            txtdiscount.Clear();
            txtQnt.Clear();
            txtvalue.Clear();
            label4.ForeColor = Color.Black;
        }

        private void bntExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnEnd_Click(object sender, EventArgs e)
        {
            if (btnEnd.Text == "Приключване")
            {
                txtTotalCountSales.Text = listvalue.Count().ToString();
                txtTotalDiscount.Text = listdiscount.Sum().ToString();
                txtTotalValue.Text = listvalue.Sum().ToString();

                btnNewSales.Enabled = false;
                btnTotal.Enabled = true;


                cb_item.Enabled = false;
                txtprice.Enabled = false;
                txtQnt.Enabled = false;

                btnEnd.Text = "Нова операция";

                if (cm.Text == "£") {
                    txt1.Text = listvalue.Count().ToString();
                    double discountpound = (Convert.ToDouble(txtTotalDiscount.Text)) * 2.21;
                    txt2.Text = discountpound.ToString();
                    double valuepound = (Convert.ToDouble(txtTotalValue.Text)) * 2.21;
                    txt3.Text = valuepound.ToString();

                }
                else if (cm.Text =="$") {
                    txt1.Text = listvalue.Count().ToString();
                    double discountdollar = (Convert.ToDouble(txtTotalDiscount.Text)) * 1.21;
                    txt2.Text = discountdollar.ToString();
                    double valuepound = (Convert.ToDouble(txtTotalValue.Text)) * 1.21;
                    txt3.Text = valuepound.ToString();
                }
                else
                {
                    txt1.Text = listvalue.Count().ToString();
                    double discountcash = (Convert.ToDouble(txtTotalDiscount.Text));
                    txt2.Text = discountcash.ToString();
                    double valuecash = (Convert.ToDouble(txtTotalValue.Text));
                    txt3.Text = valuecash.ToString();
                }
                string[] row = { Convert.ToString(dateTimePicker1.Value), cb_item.Text,
txtprice.Text, txtQnt.Text, txtdiscount.Text, txtvalue.Text };
                ListViewItem it = new ListViewItem(row);
                listView1.Items.Add(it);

            }
            else 
            {
                cb_item.ResetText();
                //cb_item.SelectedIndex = -1;
                txtprice.Clear();
                txtQnt.Clear();
                txtdiscount.Clear();
                txtvalue.Clear();
                dateTimePicker1.Enabled = true;
                cm.Enabled = true;
                
                txtTotalCountSales.Clear();
                txtTotalDiscount.Clear();
                txtTotalValue.Clear();
                cb_item.Enabled = true;
                txtprice.Enabled = true;
                txtQnt.Enabled = true;
                btnEnd.Text = "Приключване";
                btnTotal.Enabled = true;
                txtTotalDiscount.ForeColor = Color.Black;
                listdiscount.Clear();
                listvalue.Clear();
                txt1.Clear();
                txt2.Clear();
                txt3.Clear();

            }




        }

        private void txtTotalDiscount_TextChanged(object sender, EventArgs e)
        {
            var list =listdiscount.Sum();
            if (list > 0){
                label7.ForeColor = Color.Red;
            }
            else {
                label7.ForeColor = Color.Black;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] items = { "Артикул 1", "Артикул 2", "Артикул 3" };
            cb_item.DataSource = items;
            cb_item.SelectedIndex = -1;
            
        }

        private void toolTip1_Popup(object sender, PopupEventArgs e)
        {
            
        }

        private void txtprice_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cm_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }
    }
    class MyException : Exception
    {
        public MyException(string str)
        {
            MessageBox.Show("User defined exception: " + str);
        }
    }

}
