﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UIDesignDev
{
    public partial class frm1 : Form
    {
        public frm1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lblphone_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            richTextBox1.Text += persondatedox.Text + Environment.NewLine + textBox1.Text 
                + Environment.NewLine + maskedTextBox1.Text + Environment.NewLine 
                + textBox3.Text + Environment.NewLine+ Environment.NewLine;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            richTextBox1.Text +=Unibox.Text+ Environment.NewLine+ maskedTextBox2.Text + Environment.NewLine
                + comboBox1.Text + Environment.NewLine 
                + comboBox2.Text + Environment.NewLine + Environment.NewLine;


        }

        private void button3_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
            textBox1.Clear();
            textBox3.Clear();
            maskedTextBox1.Clear();
            maskedTextBox2.Clear();
            comboBox1.ResetText();
            comboBox2.ResetText();
            
        }
    }
}
