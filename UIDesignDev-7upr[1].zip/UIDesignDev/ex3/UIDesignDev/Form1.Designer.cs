﻿namespace UIDesignDev
{
    partial class frm1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.persondatedox = new System.Windows.Forms.GroupBox();
            this.Unibox = new System.Windows.Forms.GroupBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.lblname = new System.Windows.Forms.Label();
            this.lblphone = new System.Windows.Forms.Label();
            this.lblAdress = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.lblfn = new System.Windows.Forms.Label();
            this.lblgroup = new System.Windows.Forms.Label();
            this.lblnapravlenie = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.maskedTextBox2 = new System.Windows.Forms.MaskedTextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.persondatedox.SuspendLayout();
            this.Unibox.SuspendLayout();
            this.SuspendLayout();
            // 
            // persondatedox
            // 
            this.persondatedox.Controls.Add(this.maskedTextBox1);
            this.persondatedox.Controls.Add(this.button1);
            this.persondatedox.Controls.Add(this.textBox3);
            this.persondatedox.Controls.Add(this.textBox1);
            this.persondatedox.Controls.Add(this.lblAdress);
            this.persondatedox.Controls.Add(this.lblphone);
            this.persondatedox.Controls.Add(this.lblname);
            this.persondatedox.Location = new System.Drawing.Point(0, 0);
            this.persondatedox.Name = "persondatedox";
            this.persondatedox.Size = new System.Drawing.Size(305, 149);
            this.persondatedox.TabIndex = 0;
            this.persondatedox.TabStop = false;
            this.persondatedox.Text = "Лични данни";
            // 
            // Unibox
            // 
            this.Unibox.Controls.Add(this.button2);
            this.Unibox.Controls.Add(this.maskedTextBox2);
            this.Unibox.Controls.Add(this.comboBox2);
            this.Unibox.Controls.Add(this.comboBox1);
            this.Unibox.Controls.Add(this.lblnapravlenie);
            this.Unibox.Controls.Add(this.lblgroup);
            this.Unibox.Controls.Add(this.lblfn);
            this.Unibox.Location = new System.Drawing.Point(311, 0);
            this.Unibox.Name = "Unibox";
            this.Unibox.Size = new System.Drawing.Size(373, 149);
            this.Unibox.TabIndex = 0;
            this.Unibox.TabStop = false;
            this.Unibox.Text = "Университетски данни";
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Location = new System.Drawing.Point(6, 36);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(84, 13);
            this.lblname.TabIndex = 0;
            this.lblname.Text = "Име, Фамилия";
            // 
            // lblphone
            // 
            this.lblphone.AutoSize = true;
            this.lblphone.Location = new System.Drawing.Point(6, 65);
            this.lblphone.Name = "lblphone";
            this.lblphone.Size = new System.Drawing.Size(52, 13);
            this.lblphone.TabIndex = 1;
            this.lblphone.Text = "Телефон";
            this.lblphone.Click += new System.EventHandler(this.lblphone_Click);
            // 
            // lblAdress
            // 
            this.lblAdress.AutoSize = true;
            this.lblAdress.Location = new System.Drawing.Point(6, 95);
            this.lblAdress.Name = "lblAdress";
            this.lblAdress.Size = new System.Drawing.Size(38, 13);
            this.lblAdress.TabIndex = 2;
            this.lblAdress.Text = "Адрес";
            this.lblAdress.Click += new System.EventHandler(this.label1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(96, 36);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(203, 20);
            this.textBox1.TabIndex = 3;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(75, 88);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(224, 20);
            this.textBox3.TabIndex = 5;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 114);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(287, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "Запазване на данните";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.Location = new System.Drawing.Point(96, 62);
            this.maskedTextBox1.Mask = "(999) 000-0000";
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.Size = new System.Drawing.Size(203, 20);
            this.maskedTextBox1.TabIndex = 7;
            // 
            // lblfn
            // 
            this.lblfn.AutoSize = true;
            this.lblfn.Location = new System.Drawing.Point(6, 39);
            this.lblfn.Name = "lblfn";
            this.lblfn.Size = new System.Drawing.Size(26, 13);
            this.lblfn.TabIndex = 1;
            this.lblfn.Text = "ФН";
            // 
            // lblgroup
            // 
            this.lblgroup.AutoSize = true;
            this.lblgroup.Location = new System.Drawing.Point(6, 65);
            this.lblgroup.Name = "lblgroup";
            this.lblgroup.Size = new System.Drawing.Size(36, 13);
            this.lblgroup.TabIndex = 2;
            this.lblgroup.Text = "Група";
            // 
            // lblnapravlenie
            // 
            this.lblnapravlenie.AutoSize = true;
            this.lblnapravlenie.Location = new System.Drawing.Point(6, 95);
            this.lblnapravlenie.Name = "lblnapravlenie";
            this.lblnapravlenie.Size = new System.Drawing.Size(75, 13);
            this.lblnapravlenie.TabIndex = 3;
            this.lblnapravlenie.Text = "Направление";
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Разработка и проектиране на бизнес информационни системи",
            "Анализ и проектиране на бизнес информационни системи"});
            this.comboBox1.Location = new System.Drawing.Point(149, 88);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(218, 21);
            this.comboBox1.TabIndex = 4;
            // 
            // comboBox2
            // 
            this.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "1536",
            "1537"});
            this.comboBox2.Location = new System.Drawing.Point(149, 62);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(203, 21);
            this.comboBox2.TabIndex = 5;
            // 
            // maskedTextBox2
            // 
            this.maskedTextBox2.Location = new System.Drawing.Point(149, 36);
            this.maskedTextBox2.Mask = "0000000";
            this.maskedTextBox2.Name = "maskedTextBox2";
            this.maskedTextBox2.Size = new System.Drawing.Size(203, 20);
            this.maskedTextBox2.TabIndex = 6;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(9, 114);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(343, 23);
            this.button2.TabIndex = 7;
            this.button2.Text = "Запазване на данните";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.richTextBox1.Location = new System.Drawing.Point(12, 171);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(331, 165);
            this.richTextBox1.TabIndex = 1;
            this.richTextBox1.Text = "";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(591, 282);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(93, 40);
            this.button3.TabIndex = 2;
            this.button3.Text = "Изчистване на полетата";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // frm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(696, 348);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.Unibox);
            this.Controls.Add(this.persondatedox);
            this.Name = "frm1";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Упражнение 1 ";
            this.persondatedox.ResumeLayout(false);
            this.persondatedox.PerformLayout();
            this.Unibox.ResumeLayout(false);
            this.Unibox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox persondatedox;
        private System.Windows.Forms.Label lblAdress;
        private System.Windows.Forms.Label lblphone;
        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.GroupBox Unibox;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.MaskedTextBox maskedTextBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.MaskedTextBox maskedTextBox2;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label lblnapravlenie;
        private System.Windows.Forms.Label lblgroup;
        private System.Windows.Forms.Label lblfn;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Button button3;
    }
}

