﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MdiApp
{
    public partial class Sales_ : Form
    {
        public Sales_()
        {
            InitializeComponent();
        }

        private void Sales_activation_Load(object sender, EventArgs e)
        {

        }

        private void Sales__Activated(object sender, EventArgs e)
        {
            
                Form frm = (Form)Application.OpenForms["Sales"];
                ToolStrip strip = (ToolStrip)frm.Controls["statusStrip1"];
                strip.Items[0].Text = this.Text;


            
        }
    }
}
