﻿namespace MdiApp
{


    partial class exe7DataSet
    {
    }
}

namespace MdiApp.exe7DataSetTableAdapters {
    
    
    public partial class CustomersTableAdapter {
    }
}
