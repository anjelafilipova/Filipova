﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MdiApp
{
    public partial class Customer : Form
    {
        int ID = 0;
        bool edit = false;

        public Customer()
        {
            InitializeComponent();
        }
        public Customer(bool parm_edint, int? Parm_ID)
        {
            InitializeComponent();
            edit = parm_edint;
            if (Parm_ID.HasValue)
            {
                ID = Parm_ID.Value;
            }
        }

        private void customersBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.customersBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.exe7DataSet);

        }

        private void Customer_Load(object sender, EventArgs e)
        {
            if (edit)
            {
                if (ID == 0)
                {
                    AskIDForm f = new AskIDForm();
                    f.ShowDialog();
                    //ID = f.ReturnedID;
                    f.Close();
                    if (ID != 0)
                    {
                        this.Text = "Продажба " + ID.ToString();
                    }
                    else if (ID == 0)
                    {
                        this.BeginInvoke(new MethodInvoker(this.Close));
                    }
                }
                // TODO: This line of code loads data into the 'exe7DataSet.Customers' table. You can move, or remove it, as needed.
                this.customersTableAdapter.Fill(this.exe7DataSet.Customers);

            }
        }

        private void Save_btn_Click(object sender, EventArgs e)
        {
            if (customersIDTextBox.Text.Equals("") && !nameTextBox.Text.Equals(""))
            {
                customersTableAdapter.Insert(nameTextBox.Text);
            }
            this.Validate();
            this.customersBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.exe7DataSet);

        }
    }
}
