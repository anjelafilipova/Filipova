﻿namespace MdiApp
{
    partial class Sales
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.изходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.клиентиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.списъкСКлиентиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.новКлиентToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.редакцияНаКлиентToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.продажбиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.списъкСПродажбиНToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.новиПродажбиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.редакцияНаПродажбаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.номенклатуриToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.артикулиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.прозорциToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.хоризонталноToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.вертикалноПодрежданеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.каскадноПодрежданеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.затварянеНаВсичкиПрозорциToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.клиентиToolStripMenuItem,
            this.продажбиToolStripMenuItem,
            this.номенклатуриToolStripMenuItem,
            this.прозорциToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(641, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.изходToolStripMenuItem});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.файлToolStripMenuItem.Text = "Файл";
            // 
            // изходToolStripMenuItem
            // 
            this.изходToolStripMenuItem.Name = "изходToolStripMenuItem";
            this.изходToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.изходToolStripMenuItem.Text = "Изход";
            this.изходToolStripMenuItem.Click += new System.EventHandler(this.изходToolStripMenuItem_Click);
            // 
            // клиентиToolStripMenuItem
            // 
            this.клиентиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.списъкСКлиентиToolStripMenuItem,
            this.новКлиентToolStripMenuItem,
            this.редакцияНаКлиентToolStripMenuItem});
            this.клиентиToolStripMenuItem.Name = "клиентиToolStripMenuItem";
            this.клиентиToolStripMenuItem.Size = new System.Drawing.Size(65, 20);
            this.клиентиToolStripMenuItem.Text = "Клиенти";
            // 
            // списъкСКлиентиToolStripMenuItem
            // 
            this.списъкСКлиентиToolStripMenuItem.Name = "списъкСКлиентиToolStripMenuItem";
            this.списъкСКлиентиToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.списъкСКлиентиToolStripMenuItem.Text = "Списък с клиенти";
            this.списъкСКлиентиToolStripMenuItem.Click += new System.EventHandler(this.списъкСКлиентиToolStripMenuItem_Click);
            // 
            // новКлиентToolStripMenuItem
            // 
            this.новКлиентToolStripMenuItem.Name = "новКлиентToolStripMenuItem";
            this.новКлиентToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.новКлиентToolStripMenuItem.Text = "Нов Клиент";
            // 
            // редакцияНаКлиентToolStripMenuItem
            // 
            this.редакцияНаКлиентToolStripMenuItem.Name = "редакцияНаКлиентToolStripMenuItem";
            this.редакцияНаКлиентToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.редакцияНаКлиентToolStripMenuItem.Text = "Редакция на клиент";
            // 
            // продажбиToolStripMenuItem
            // 
            this.продажбиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.списъкСПродажбиНToolStripMenuItem,
            this.новиПродажбиToolStripMenuItem,
            this.редакцияНаПродажбаToolStripMenuItem});
            this.продажбиToolStripMenuItem.Name = "продажбиToolStripMenuItem";
            this.продажбиToolStripMenuItem.Size = new System.Drawing.Size(77, 20);
            this.продажбиToolStripMenuItem.Text = "Продажби";
            // 
            // списъкСПродажбиНToolStripMenuItem
            // 
            this.списъкСПродажбиНToolStripMenuItem.Name = "списъкСПродажбиНToolStripMenuItem";
            this.списъкСПродажбиНToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
            this.списъкСПродажбиНToolStripMenuItem.Text = "Списък с продажби ";
            this.списъкСПродажбиНToolStripMenuItem.Click += new System.EventHandler(this.списъкСПродажбиНToolStripMenuItem_Click);
            // 
            // новиПродажбиToolStripMenuItem
            // 
            this.новиПродажбиToolStripMenuItem.Name = "новиПродажбиToolStripMenuItem";
            this.новиПродажбиToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
            this.новиПродажбиToolStripMenuItem.Text = "Нова продажби";
            this.новиПродажбиToolStripMenuItem.Click += new System.EventHandler(this.новиПродажбиToolStripMenuItem_Click);
            // 
            // редакцияНаПродажбаToolStripMenuItem
            // 
            this.редакцияНаПродажбаToolStripMenuItem.Name = "редакцияНаПродажбаToolStripMenuItem";
            this.редакцияНаПродажбаToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
            this.редакцияНаПродажбаToolStripMenuItem.Text = "Редакция на продажба";
            // 
            // номенклатуриToolStripMenuItem
            // 
            this.номенклатуриToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.артикулиToolStripMenuItem});
            this.номенклатуриToolStripMenuItem.Name = "номенклатуриToolStripMenuItem";
            this.номенклатуриToolStripMenuItem.Size = new System.Drawing.Size(101, 20);
            this.номенклатуриToolStripMenuItem.Text = "Номенклатури";
            // 
            // артикулиToolStripMenuItem
            // 
            this.артикулиToolStripMenuItem.Name = "артикулиToolStripMenuItem";
            this.артикулиToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.артикулиToolStripMenuItem.Text = "Артикули";
            // 
            // прозорциToolStripMenuItem
            // 
            this.прозорциToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.хоризонталноToolStripMenuItem,
            this.вертикалноПодрежданеToolStripMenuItem,
            this.каскадноПодрежданеToolStripMenuItem,
            this.затварянеНаВсичкиПрозорциToolStripMenuItem});
            this.прозорциToolStripMenuItem.Name = "прозорциToolStripMenuItem";
            this.прозорциToolStripMenuItem.Size = new System.Drawing.Size(75, 20);
            this.прозорциToolStripMenuItem.Text = "Прозорци";
            // 
            // хоризонталноToolStripMenuItem
            // 
            this.хоризонталноToolStripMenuItem.Name = "хоризонталноToolStripMenuItem";
            this.хоризонталноToolStripMenuItem.Size = new System.Drawing.Size(245, 22);
            this.хоризонталноToolStripMenuItem.Text = "Хоризонтално подреждане";
            this.хоризонталноToolStripMenuItem.Click += new System.EventHandler(this.хоризонталноToolStripMenuItem_Click);
            // 
            // вертикалноПодрежданеToolStripMenuItem
            // 
            this.вертикалноПодрежданеToolStripMenuItem.Name = "вертикалноПодрежданеToolStripMenuItem";
            this.вертикалноПодрежданеToolStripMenuItem.Size = new System.Drawing.Size(245, 22);
            this.вертикалноПодрежданеToolStripMenuItem.Text = "Вертикално подреждане";
            this.вертикалноПодрежданеToolStripMenuItem.Click += new System.EventHandler(this.вертикалноПодрежданеToolStripMenuItem_Click);
            // 
            // каскадноПодрежданеToolStripMenuItem
            // 
            this.каскадноПодрежданеToolStripMenuItem.Name = "каскадноПодрежданеToolStripMenuItem";
            this.каскадноПодрежданеToolStripMenuItem.Size = new System.Drawing.Size(245, 22);
            this.каскадноПодрежданеToolStripMenuItem.Text = "Каскадно подреждане";
            this.каскадноПодрежданеToolStripMenuItem.Click += new System.EventHandler(this.каскадноПодрежданеToolStripMenuItem_Click);
            // 
            // затварянеНаВсичкиПрозорциToolStripMenuItem
            // 
            this.затварянеНаВсичкиПрозорциToolStripMenuItem.Name = "затварянеНаВсичкиПрозорциToolStripMenuItem";
            this.затварянеНаВсичкиПрозорциToolStripMenuItem.Size = new System.Drawing.Size(245, 22);
            this.затварянеНаВсичкиПрозорциToolStripMenuItem.Text = "Затваряне на всички прозорци";
            this.затварянеНаВсичкиПрозорциToolStripMenuItem.Click += new System.EventHandler(this.затварянеНаВсичкиПрозорциToolStripMenuItem_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 425);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(641, 22);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(118, 17);
            this.toolStripStatusLabel1.Text = "toolStripStatusLabel1";
            // 
            // Sales
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(641, 447);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Sales";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Sales_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem изходToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem клиентиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem списъкСКлиентиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem новКлиентToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem редакцияНаКлиентToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem продажбиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem списъкСПродажбиНToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem новиПродажбиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem редакцияНаПродажбаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem номенклатуриToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem артикулиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem прозорциToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem хоризонталноToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem вертикалноПодрежданеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem каскадноПодрежданеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem затварянеНаВсичкиПрозорциToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
    }
}

