﻿namespace MdiApp
{
    partial class Customer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label customersIDLabel;
            System.Windows.Forms.Label nameLabel;
            this.exe7DataSet = new MdiApp.exe7DataSet();
            this.customersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.customersTableAdapter = new MdiApp.exe7DataSetTableAdapters.CustomersTableAdapter();
            this.tableAdapterManager = new MdiApp.exe7DataSetTableAdapters.TableAdapterManager();
            this.customersIDTextBox = new System.Windows.Forms.TextBox();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.Save_btn = new System.Windows.Forms.Button();
            this.No_btn = new System.Windows.Forms.Button();
            customersIDLabel = new System.Windows.Forms.Label();
            nameLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.exe7DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customersBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // customersIDLabel
            // 
            customersIDLabel.AutoSize = true;
            customersIDLabel.Location = new System.Drawing.Point(31, 72);
            customersIDLabel.Name = "customersIDLabel";
            customersIDLabel.Size = new System.Drawing.Size(73, 13);
            customersIDLabel.TabIndex = 1;
            customersIDLabel.Text = "Customers ID:";
            // 
            // nameLabel
            // 
            nameLabel.AutoSize = true;
            nameLabel.Location = new System.Drawing.Point(31, 98);
            nameLabel.Name = "nameLabel";
            nameLabel.Size = new System.Drawing.Size(38, 13);
            nameLabel.TabIndex = 3;
            nameLabel.Text = "Name:";
            // 
            // exe7DataSet
            // 
            this.exe7DataSet.DataSetName = "exe7DataSet";
            this.exe7DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // customersBindingSource
            // 
            this.customersBindingSource.DataMember = "Customers";
            this.customersBindingSource.DataSource = this.exe7DataSet;
            // 
            // customersTableAdapter
            // 
            this.customersTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CustomersTableAdapter = this.customersTableAdapter;
            this.tableAdapterManager.ProductsTableAdapter = null;
            this.tableAdapterManager.SalesLineTableAdapter = null;
            this.tableAdapterManager.SalesTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = MdiApp.exe7DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // customersIDTextBox
            // 
            this.customersIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customersBindingSource, "CustomersID", true));
            this.customersIDTextBox.Location = new System.Drawing.Point(110, 69);
            this.customersIDTextBox.Name = "customersIDTextBox";
            this.customersIDTextBox.Size = new System.Drawing.Size(100, 20);
            this.customersIDTextBox.TabIndex = 2;
            // 
            // nameTextBox
            // 
            this.nameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customersBindingSource, "Name", true));
            this.nameTextBox.Location = new System.Drawing.Point(110, 95);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(100, 20);
            this.nameTextBox.TabIndex = 4;
            // 
            // Save_btn
            // 
            this.Save_btn.Location = new System.Drawing.Point(49, 138);
            this.Save_btn.Name = "Save_btn";
            this.Save_btn.Size = new System.Drawing.Size(75, 23);
            this.Save_btn.TabIndex = 5;
            this.Save_btn.Text = "Запис";
            this.Save_btn.UseVisualStyleBackColor = true;
            this.Save_btn.Click += new System.EventHandler(this.Save_btn_Click);
            // 
            // No_btn
            // 
            this.No_btn.Location = new System.Drawing.Point(173, 138);
            this.No_btn.Name = "No_btn";
            this.No_btn.Size = new System.Drawing.Size(75, 23);
            this.No_btn.TabIndex = 6;
            this.No_btn.Text = "Отказ";
            this.No_btn.UseVisualStyleBackColor = true;
            // 
            // Customer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(311, 189);
            this.Controls.Add(this.No_btn);
            this.Controls.Add(this.Save_btn);
            this.Controls.Add(customersIDLabel);
            this.Controls.Add(this.customersIDTextBox);
            this.Controls.Add(nameLabel);
            this.Controls.Add(this.nameTextBox);
            this.Name = "Customer";
            this.Text = "Customer";
            this.Load += new System.EventHandler(this.Customer_Load);
            ((System.ComponentModel.ISupportInitialize)(this.exe7DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customersBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private exe7DataSet exe7DataSet;
        private System.Windows.Forms.BindingSource customersBindingSource;
        private exe7DataSetTableAdapters.CustomersTableAdapter customersTableAdapter;
        private exe7DataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.TextBox customersIDTextBox;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.Button Save_btn;
        private System.Windows.Forms.Button No_btn;
    }
}