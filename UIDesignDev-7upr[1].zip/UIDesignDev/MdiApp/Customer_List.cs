﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MdiApp
{
    public partial class Customer_List : Form
    {
        public Customer_List()
        {
            InitializeComponent();
        }

        private void customersBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.customersBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.exe7DataSet);

        }

        private void Customer_List_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'exe7DataSet.Customers' table. You can move, or remove it, as needed.
            this.customersTableAdapter.Fill(this.exe7DataSet.Customers);

        }

        private void Search_btn_Click(object sender, EventArgs e)
        {
            this.customersTableAdapter.FillBySearch(this.exe7DataSet.Customers, Name_txt.Text);
        }

        private void customersDataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex>=0 && customersDataGridView.Columns[e.ColumnIndex].Name.Equals("Edit"))
            {
                Customer customer = new Customer(true, Convert.ToInt32(customersDataGridView.CurrentRow.Cells[0].Value));
                
            }
        }

        private void customersDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
