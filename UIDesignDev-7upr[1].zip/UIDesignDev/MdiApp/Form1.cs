﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MdiApp
{
    public partial class Sales : Form
    {
        public Sales()
        {
            InitializeComponent();
        }

        private void Sales_Load(object sender, EventArgs e)
        {
        //    Sales f = new Sales();
        //    f.MdiParent = this;
        //    f.Show();
        }

        private void списъкСПродажбиНToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Sales_ sa = new Sales_();
            sa.MdiParent = this;
            sa.Show();
            toolStripStatusLabel1.Text = "Списък С Продажби";
        }

        private void хоризонталноToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void вертикалноПодрежданеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.TileVertical);
        }

        private void каскадноПодрежданеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.Cascade);
        }

        private void затварянеНаВсичкиПрозорциToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form aForm in this.MdiChildren)
            {
                if (aForm.IsMdiContainer != true)
                {
                    aForm.Close();
                }
            }
            }

        private void изходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure? Do you want to close the form?", " ", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                Application.Exit();
            }
            else if (dialogResult == DialogResult.No)
            {

            }
        }

       

        private void новиПродажбиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            New_sales ns = new New_sales();
            ns.MdiParent = this;
            ns.Show();
            toolStripStatusLabel1.Text = "Нови Продажби";

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void списъкСКлиентиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Customer_List customer_List = new Customer_List();
            customer_List.MdiParent = this;
            customer_List.Show();
            toolStripStatusLabel1.Text = "Списък с Клиенти";
        }
    }
}
