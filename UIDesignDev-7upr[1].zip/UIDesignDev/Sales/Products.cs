﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sales
{
    public partial class Products : Form
    {
        public Products()
        {
            InitializeComponent();
        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {

        }

        private void treeView1_DockChanged(object sender, EventArgs e)
        {
            
        }

        private void Item_form_FormClosing(object sender, FormClosingEventArgs e)
        {
            foreach(Form f in Application.OpenForms)
                //wsichki otvoreni formi na app
            {
                //ako imeto na otvorenata forma e glavnata forma
                if (f.Name.Equals("Form1"))
                {
                    Control[] cntrl = f.Controls.Find("dataGridView1", true);
                    cntrl[0].Tag = treeView1.SelectedNode.Text;
                }

            }
        }

        private void treeView1_DoubleClick(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
