﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sales
{

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtdescount_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            double d = 0;

            double v = (Convert.ToDouble(dataGridView1.CurrentRow.Cells[One_price.Name].Value) *
                (Convert.ToDouble(dataGridView1.CurrentRow.Cells[qunt_clm.Name].Value)));

            if (v > 100)
            {

                d = 0.1*v  ;
                   // Convert.ToDouble(dataGridView1.CurrentRow.Cells[One_price.Name].Value) *
                    //Convert.ToDouble(dataGridView1.CurrentRow.Cells[qunt_clm.Name].Value);
                v -= d;

                //MessageBox.Show("ee",d.ToString());

            }

            dataGridView1.CurrentRow.Cells[discouunt_clm.Name].Value = d.ToString();
            dataGridView1.CurrentRow.Cells[price.Name].Value = v.ToString();

            int countrow = dataGridView1.RowCount - 1;
            //MessageBox.Show("ee",countrow.ToString());

            double allDiscount = 0 , allPrice = 0;

            for (var i = 0; i < countrow; i++)
            {
                allDiscount += Convert.ToDouble(dataGridView1.Rows[i].Cells[discouunt_clm.Name].Value);
                allPrice += Convert.ToDouble(dataGridView1.Rows[i].Cells[price.Name].Value);

            }

            txtTotalDiscount.Text   = allDiscount.ToString();
            txtTotalValue.Text      = allPrice.ToString();
            txtTotalCountSales.Text = countrow.ToString();

        }

        private void textBox2_Validating(object sender, CancelEventArgs e)
        {
            if (textBox2.Text == "")
            {
                errorProvider1.SetError(textBox2, "Ne ste vyveli stoinost");
            }
            else { errorProvider1.SetError(textBox2, ""); }
        }

        private void изходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure? Do you want to close the form?", " ", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                this.Close();
            }
            else if (dialogResult == DialogResult.No)
            {
                
            }
        }

        private void смянаНаЦвятToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult res = colorDialog1.ShowDialog();
            if (res == DialogResult.OK)
            {
                this.BackColor = colorDialog1.Color;
            }
        }

        private void изходToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure? Do you want to close the form?", " ", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                this.Close();
            }
            else if (dialogResult == DialogResult.No)
            {

            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void артикулиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Products p = new Products();
            p.MdiParent = this.MdiParent;
            p.Show();


        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.Columns[e.ColumnIndex].Name.Equals("Item_clm"))
            {
                
                Products itm = new Products();
                itm.ShowDialog();
                dataGridView1.CurrentCell.Value = dataGridView1.Tag;

            }
        }
    }

}