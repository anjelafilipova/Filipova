﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InvoiceTracking
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            main1.BringToFront();

        }
        
        private void документToolStripMenuItem_Click(object sender, EventArgs e)
        {
            document1.BringToFront();
            label1.Text = "Документи";
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void издаванеНаДокуметToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Visible = true;
            newInvoice1.BringToFront();
            label1.Text = "Издаване на докумет";

        }

        private void регистриранеНаПлащанеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            payments1.BringToFront();
            label1.Text = "Регистриране на плащане";
        }

        private void патньориToolStripMenuItem_Click(object sender, EventArgs e)
        {
            partner1.BringToFront();
            label1.Text = "Патньори";
        }

        private void издадениДокументиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            docReports1.BringToFront();
            label1.Text = "Издадени документи ";
        }

        private void изходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (DialogResult.OK == MessageBox.Show("Are you sure? Do you want to close the program? ", "Quit", MessageBoxButtons.OKCancel))
                this.Close();
        }

        private void партньориToolStripMenuItem_Click(object sender, EventArgs e)
        {
            partnerReports1.BringToFront();
            label1.Text = "Справка партньори";
        }

        private void новаФирмаToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void button2_Click(object sender, EventArgs e)
        {
            partner1.BringToFront();
            label1.Text = "Партньори";

        }

        private void button3_Click(object sender, EventArgs e)
        {
            newInvoice1.BringToFront();
            label1.Text = "Издаване на документи";


        }

        private void button5_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Сигурни ли сте че искате да излезете от приложението", " ", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                Application.Exit();
            }
            else if (dialogResult == DialogResult.No)
            {

            }
            
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            docReports1.BringToFront();
            label1.Text = "Документи";

        }

        private void button1_Click(object sender, EventArgs e)
        {
            main1.BringToFront();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            payments1.BringToFront();
            label1.Text = "Регистриране на плащане";

        }

        private void docReports1_Load(object sender, EventArgs e)
        {

        }

        private void payments1_Load(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
          
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void payments1_Load_1(object sender, EventArgs e)
        {

        }

        private void просрочениФактуриToolStripMenuItem_Click(object sender, EventArgs e)
        {
            main1.BringToFront();
            label1.Text = "Просрочени фактури ";

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
