﻿namespace InvoiceTracking
{
    partial class Partner
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.pARTNERIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pARTNERNAMEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pARTNERSURNAMEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pARTNERLASTNAMEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pARTNEREGNDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pARTNERTFULLNAMEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pARTNERBULSTATDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pARTNEREMAILDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pARTNERPHONEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pARTNERADDRESSDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pARTNERBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.personalFinancesDataSet = new InvoiceTracking.PersonalFinancesDataSet();
            this.pARTNERTableAdapter = new InvoiceTracking.PersonalFinancesDataSetTableAdapters.PARTNERTableAdapter();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pARTNERBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.personalFinancesDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button3);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Location = new System.Drawing.Point(541, 266);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(249, 67);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Партньори";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Location = new System.Drawing.Point(135, 23);
            this.button3.Margin = new System.Windows.Forms.Padding(2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(97, 32);
            this.button3.TabIndex = 4;
            this.button3.Text = "Изтриване";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(11, 23);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(88, 32);
            this.button1.TabIndex = 3;
            this.button1.Text = "Нов";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.pARTNERIDDataGridViewTextBoxColumn,
            this.pARTNERNAMEDataGridViewTextBoxColumn,
            this.pARTNERSURNAMEDataGridViewTextBoxColumn,
            this.pARTNERLASTNAMEDataGridViewTextBoxColumn,
            this.pARTNEREGNDataGridViewTextBoxColumn,
            this.pARTNERTFULLNAMEDataGridViewTextBoxColumn,
            this.pARTNERBULSTATDataGridViewTextBoxColumn,
            this.pARTNEREMAILDataGridViewTextBoxColumn,
            this.pARTNERPHONEDataGridViewTextBoxColumn,
            this.pARTNERADDRESSDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.pARTNERBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(29, 53);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(733, 204);
            this.dataGridView1.TabIndex = 3;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentDoubleClick);
            this.dataGridView1.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            this.dataGridView1.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellEndEdit);
            // 
            // pARTNERIDDataGridViewTextBoxColumn
            // 
            this.pARTNERIDDataGridViewTextBoxColumn.DataPropertyName = "PARTNER_ID";
            this.pARTNERIDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.pARTNERIDDataGridViewTextBoxColumn.Name = "pARTNERIDDataGridViewTextBoxColumn";
            this.pARTNERIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.pARTNERIDDataGridViewTextBoxColumn.Width = 25;
            // 
            // pARTNERNAMEDataGridViewTextBoxColumn
            // 
            this.pARTNERNAMEDataGridViewTextBoxColumn.DataPropertyName = "PARTNER_NAME";
            this.pARTNERNAMEDataGridViewTextBoxColumn.HeaderText = "Име";
            this.pARTNERNAMEDataGridViewTextBoxColumn.Name = "pARTNERNAMEDataGridViewTextBoxColumn";
            // 
            // pARTNERSURNAMEDataGridViewTextBoxColumn
            // 
            this.pARTNERSURNAMEDataGridViewTextBoxColumn.DataPropertyName = "PARTNER_SURNAME";
            this.pARTNERSURNAMEDataGridViewTextBoxColumn.HeaderText = "Презиме";
            this.pARTNERSURNAMEDataGridViewTextBoxColumn.Name = "pARTNERSURNAMEDataGridViewTextBoxColumn";
            // 
            // pARTNERLASTNAMEDataGridViewTextBoxColumn
            // 
            this.pARTNERLASTNAMEDataGridViewTextBoxColumn.DataPropertyName = "PARTNER_LASTNAME";
            this.pARTNERLASTNAMEDataGridViewTextBoxColumn.HeaderText = "Фамилия";
            this.pARTNERLASTNAMEDataGridViewTextBoxColumn.Name = "pARTNERLASTNAMEDataGridViewTextBoxColumn";
            // 
            // pARTNEREGNDataGridViewTextBoxColumn
            // 
            this.pARTNEREGNDataGridViewTextBoxColumn.DataPropertyName = "PARTNER_EGN";
            this.pARTNEREGNDataGridViewTextBoxColumn.HeaderText = "ЕГН";
            this.pARTNEREGNDataGridViewTextBoxColumn.Name = "pARTNEREGNDataGridViewTextBoxColumn";
            // 
            // pARTNERTFULLNAMEDataGridViewTextBoxColumn
            // 
            this.pARTNERTFULLNAMEDataGridViewTextBoxColumn.DataPropertyName = "PARTNERT_FULLNAME";
            this.pARTNERTFULLNAMEDataGridViewTextBoxColumn.HeaderText = "Фирма";
            this.pARTNERTFULLNAMEDataGridViewTextBoxColumn.Name = "pARTNERTFULLNAMEDataGridViewTextBoxColumn";
            // 
            // pARTNERBULSTATDataGridViewTextBoxColumn
            // 
            this.pARTNERBULSTATDataGridViewTextBoxColumn.DataPropertyName = "PARTNER_BULSTAT";
            this.pARTNERBULSTATDataGridViewTextBoxColumn.HeaderText = "БУЛСАТ";
            this.pARTNERBULSTATDataGridViewTextBoxColumn.Name = "pARTNERBULSTATDataGridViewTextBoxColumn";
            // 
            // pARTNEREMAILDataGridViewTextBoxColumn
            // 
            this.pARTNEREMAILDataGridViewTextBoxColumn.DataPropertyName = "PARTNER_EMAIL";
            this.pARTNEREMAILDataGridViewTextBoxColumn.HeaderText = "Имейл";
            this.pARTNEREMAILDataGridViewTextBoxColumn.Name = "pARTNEREMAILDataGridViewTextBoxColumn";
            // 
            // pARTNERPHONEDataGridViewTextBoxColumn
            // 
            this.pARTNERPHONEDataGridViewTextBoxColumn.DataPropertyName = "PARTNER_PHONE";
            this.pARTNERPHONEDataGridViewTextBoxColumn.HeaderText = "Телефон";
            this.pARTNERPHONEDataGridViewTextBoxColumn.Name = "pARTNERPHONEDataGridViewTextBoxColumn";
            // 
            // pARTNERADDRESSDataGridViewTextBoxColumn
            // 
            this.pARTNERADDRESSDataGridViewTextBoxColumn.DataPropertyName = "PARTNER_ADDRESS";
            this.pARTNERADDRESSDataGridViewTextBoxColumn.HeaderText = "Арес";
            this.pARTNERADDRESSDataGridViewTextBoxColumn.Name = "pARTNERADDRESSDataGridViewTextBoxColumn";
            // 
            // pARTNERBindingSource
            // 
            this.pARTNERBindingSource.DataMember = "PARTNER";
            this.pARTNERBindingSource.DataSource = this.personalFinancesDataSet;
            // 
            // personalFinancesDataSet
            // 
            this.personalFinancesDataSet.DataSetName = "PersonalFinancesDataSet";
            this.personalFinancesDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // pARTNERTableAdapter
            // 
            this.pARTNERTableAdapter.ClearBeforeFill = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(86, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "ИМЕ";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(123, 12);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(121, 20);
            this.textBox1.TabIndex = 5;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Location = new System.Drawing.Point(263, 10);
            this.button4.Margin = new System.Windows.Forms.Padding(2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(76, 23);
            this.button4.TabIndex = 5;
            this.button4.Text = "Търси";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // Partner
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.button4);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Partner";
            this.Size = new System.Drawing.Size(822, 348);
            this.Load += new System.EventHandler(this.Partner_Load);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pARTNERBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.personalFinancesDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource pARTNERBindingSource;
        private PersonalFinancesDataSet personalFinancesDataSet;
        private PersonalFinancesDataSetTableAdapters.PARTNERTableAdapter pARTNERTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn pARTNERIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pARTNERNAMEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pARTNERSURNAMEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pARTNERLASTNAMEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pARTNEREGNDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pARTNERTFULLNAMEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pARTNERBULSTATDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pARTNEREMAILDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pARTNERPHONEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pARTNERADDRESSDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button4;
    }
}
