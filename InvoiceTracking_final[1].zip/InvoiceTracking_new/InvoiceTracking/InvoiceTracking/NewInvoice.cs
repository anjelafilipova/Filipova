﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InvoiceTracking
{
    public partial class NewInvoice : UserControl
    {
        public NewInvoice()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {


                iNVOICETableAdapter.Insert(
               Convert.ToInt32(Partner_cmb.SelectedValue),
               textBox1.Text,
               dateTimePicker1.Value,
               Convert.ToInt32(comboBox2.SelectedValue),
               dateTimePicker2.Value,
               Convert.ToString(comboBox4.SelectedItem),
               Convert.ToDecimal(textBox5.Text),
               textBox2.Text
               );

                MessageBox.Show("", "Успешно добавяне");
                Partner_cmb.ResetText();
                comboBox2.ResetText();
                dataGridView1.ClearSelection();
                comboBox4.ResetText();
                comboBox5.ResetText();
                comboBox6.ResetText();
                comboBox7.ResetText();
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                dataGridView1.Rows.Clear();
            }
             

        
    


            catch (Exception ex)
            {
                MessageBox.Show("", "Неуспешно добавяне");
            }
            
            iNVOICETableAdapter.Fill(this.personalFinancesDataSet.INVOICE);

        }

        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox5.SelectedItem.ToString() == "Банкова сметка")
            {
                label10.Visible = true;
                comboBox6.Visible = true;
            }
            else
            {
                label10.Visible = false;
                comboBox6.Visible = false;
            }
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox4.SelectedItem.ToString() == "Neplatena")
            {
                comboBox5.Visible = false;
                comboBox6.Visible = false;
                label9.Visible = false;
                label10.Visible = false;
            }
            else
            {
                comboBox5.Visible = true;
                comboBox6.Visible = true;
                label9.Visible = true;
                label10.Visible = true;

            }
            //if (comboBox4.SelectedItem.ToString() == "Платена")
            //{

            //    comboBox5.Visible = true;
            //    comboBox6.Visible = true;
            //    label9.Visible = true;
            //    label10.Visible = true;

            //}
        }

        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            double result= (Convert.ToDouble(dataGridView1.CurrentRow.Cells[Column2.Name].Value) *
                (Convert.ToDouble(dataGridView1.CurrentRow.Cells[Column3.Name].Value)));

            dataGridView1.CurrentRow.Cells[Column4.Name].Value = result.ToString();

            double allresults = 0;

            int countrow = dataGridView1.RowCount - 1;

            for (var i = 0; i < countrow; i++)
            {
                allresults += Convert.ToDouble(dataGridView1.Rows[i].Cells[Column4.Name].Value);
                

            }
            textBox3.Text = allresults.ToString();
            double dds = Convert.ToDouble(textBox3.Text) * 0.2;
            textBox4.Text = dds.ToString();
            double total = Convert.ToDouble(textBox3.Text) + Convert.ToDouble(textBox4.Text);
            textBox5.Text = total.ToString();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Partner_cmb.ResetText();
            comboBox2.ResetText();
            dataGridView1.ClearSelection();
            comboBox4.ResetText();
            comboBox5.ResetText();
            comboBox6.ResetText();
            comboBox7.ResetText();
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            dataGridView1.Refresh();
            dataGridView1.Rows.Clear();

        }

        private void NewInvoice_Load(object sender, EventArgs e)
        {
            pARTNERTableAdapter.Fill(this.personalFinancesDataSet.PARTNER);
           
            invoicE_TYPETableAdapter1.Fill(this.personalFinancesDataSet.INVOICE_TYPE);
 iNVOICETableAdapter.Fill(this.personalFinancesDataSet.INVOICE);
            
        }

        private void dateTimePicker2_Validating(object sender, CancelEventArgs e)
        {
            if (dateTimePicker2.Value < dateTimePicker1.Value)
            {
                errorProvider1.SetError(dateTimePicker2, "Датата трябва да е равна или по-голяма от датата на издаване");

            }
            else
            {
                errorProvider1.SetError(dateTimePicker2, "");
            }
        }

        private void textBox5_Validating(object sender, CancelEventArgs e)
        {
            double a = Convert.ToDouble(textBox5.Text);
            if (a>0)
            {
                errorProvider1.SetError(textBox5, "Само положителни стойности");

            }
            else
            {
                errorProvider1.SetError(textBox5, "");
            }
        }

        private void comboBox4_Validating(object sender, CancelEventArgs e)
        {
            if (Partner_cmb.SelectedIndex.ToString()=="")
            {
                errorProvider1.SetError(Partner_cmb, "Задължително поле за попълване");

            }
            else
            {
                errorProvider1.SetError(Partner_cmb, "");
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox2.SelectedIndex.ToString() == "")
            {
                errorProvider1.SetError(comboBox2, "Задължително поле за попълване");

            }
            else
            {
                errorProvider1.SetError(comboBox2, "");
            }
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.pARTNERTableAdapter.FillBy(this.personalFinancesDataSet.PARTNER);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }
}
