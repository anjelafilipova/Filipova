﻿namespace InvoiceTracking
{
    partial class Document
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.iNVOICETYPEBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.personalFinancesDataSet = new InvoiceTracking.PersonalFinancesDataSet();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.iNVOICEIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pARTNERIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iNVOCIENODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iNVOCIEDATEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iNVOICETYPEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iNVOICEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iNVOICESTATUSDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iNVOICEVALUEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iNVOICENOTEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iNVOICEBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.pARTNERBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pARTNERTableAdapter = new InvoiceTracking.PersonalFinancesDataSetTableAdapters.PARTNERTableAdapter();
            this.iNVOICETableAdapter = new InvoiceTracking.PersonalFinancesDataSetTableAdapters.INVOICETableAdapter();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.iNVOICETYPEBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.personalFinancesDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iNVOICEBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pARTNERBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(277, 66);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "До дата";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(51, 69);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "От дата";
            // 
            // iNVOICETYPEBindingSource
            // 
            this.iNVOICETYPEBindingSource.DataMember = "INVOICE_TYPE";
            this.iNVOICETYPEBindingSource.DataSource = this.personalFinancesDataSet;
            // 
            // personalFinancesDataSet
            // 
            this.personalFinancesDataSet.DataSetName = "PersonalFinancesDataSet";
            this.personalFinancesDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(101, 63);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(2);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(131, 20);
            this.dateTimePicker1.TabIndex = 8;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(328, 62);
            this.dateTimePicker2.Margin = new System.Windows.Forms.Padding(2);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(121, 20);
            this.dateTimePicker2.TabIndex = 9;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iNVOICEIDDataGridViewTextBoxColumn,
            this.pARTNERIDDataGridViewTextBoxColumn,
            this.iNVOCIENODataGridViewTextBoxColumn,
            this.iNVOCIEDATEDataGridViewTextBoxColumn,
            this.iNVOICETYPEDataGridViewTextBoxColumn,
            this.iNVOICEDataGridViewTextBoxColumn,
            this.iNVOICESTATUSDataGridViewTextBoxColumn,
            this.iNVOICEVALUEDataGridViewTextBoxColumn,
            this.iNVOICENOTEDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.iNVOICEBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(27, 106);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(740, 158);
            this.dataGridView1.TabIndex = 12;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellEndEdit);
            this.dataGridView1.Click += new System.EventHandler(this.ShowData);
            // 
            // iNVOICEIDDataGridViewTextBoxColumn
            // 
            this.iNVOICEIDDataGridViewTextBoxColumn.DataPropertyName = "INVOICE_ID";
            this.iNVOICEIDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iNVOICEIDDataGridViewTextBoxColumn.Name = "iNVOICEIDDataGridViewTextBoxColumn";
            this.iNVOICEIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.iNVOICEIDDataGridViewTextBoxColumn.Visible = false;
            this.iNVOICEIDDataGridViewTextBoxColumn.Width = 25;
            // 
            // pARTNERIDDataGridViewTextBoxColumn
            // 
            this.pARTNERIDDataGridViewTextBoxColumn.DataPropertyName = "PARTNER_ID";
            this.pARTNERIDDataGridViewTextBoxColumn.HeaderText = "Партньор";
            this.pARTNERIDDataGridViewTextBoxColumn.Name = "pARTNERIDDataGridViewTextBoxColumn";
            // 
            // iNVOCIENODataGridViewTextBoxColumn
            // 
            this.iNVOCIENODataGridViewTextBoxColumn.DataPropertyName = "INVOCIE_NO";
            this.iNVOCIENODataGridViewTextBoxColumn.HeaderText = "Док№";
            this.iNVOCIENODataGridViewTextBoxColumn.Name = "iNVOCIENODataGridViewTextBoxColumn";
            // 
            // iNVOCIEDATEDataGridViewTextBoxColumn
            // 
            this.iNVOCIEDATEDataGridViewTextBoxColumn.DataPropertyName = "INVOCIE_DATE";
            this.iNVOCIEDATEDataGridViewTextBoxColumn.HeaderText = "Дата";
            this.iNVOCIEDATEDataGridViewTextBoxColumn.Name = "iNVOCIEDATEDataGridViewTextBoxColumn";
            // 
            // iNVOICETYPEDataGridViewTextBoxColumn
            // 
            this.iNVOICETYPEDataGridViewTextBoxColumn.DataPropertyName = "INVOICE_TYPE";
            this.iNVOICETYPEDataGridViewTextBoxColumn.HeaderText = "Тип";
            this.iNVOICETYPEDataGridViewTextBoxColumn.Name = "iNVOICETYPEDataGridViewTextBoxColumn";
            // 
            // iNVOICEDataGridViewTextBoxColumn
            // 
            this.iNVOICEDataGridViewTextBoxColumn.DataPropertyName = "INVOICE_";
            this.iNVOICEDataGridViewTextBoxColumn.HeaderText = "Платм До";
            this.iNVOICEDataGridViewTextBoxColumn.Name = "iNVOICEDataGridViewTextBoxColumn";
            // 
            // iNVOICESTATUSDataGridViewTextBoxColumn
            // 
            this.iNVOICESTATUSDataGridViewTextBoxColumn.DataPropertyName = "INVOICE_STATUS";
            this.iNVOICESTATUSDataGridViewTextBoxColumn.HeaderText = "Статус";
            this.iNVOICESTATUSDataGridViewTextBoxColumn.Name = "iNVOICESTATUSDataGridViewTextBoxColumn";
            // 
            // iNVOICEVALUEDataGridViewTextBoxColumn
            // 
            this.iNVOICEVALUEDataGridViewTextBoxColumn.DataPropertyName = "INVOICE_VALUE";
            this.iNVOICEVALUEDataGridViewTextBoxColumn.HeaderText = "С-ст";
            this.iNVOICEVALUEDataGridViewTextBoxColumn.Name = "iNVOICEVALUEDataGridViewTextBoxColumn";
            // 
            // iNVOICENOTEDataGridViewTextBoxColumn
            // 
            this.iNVOICENOTEDataGridViewTextBoxColumn.DataPropertyName = "INVOICE_NOTE";
            this.iNVOICENOTEDataGridViewTextBoxColumn.HeaderText = "Бележка";
            this.iNVOICENOTEDataGridViewTextBoxColumn.Name = "iNVOICENOTEDataGridViewTextBoxColumn";
            this.iNVOICENOTEDataGridViewTextBoxColumn.Visible = false;
            // 
            // iNVOICEBindingSource
            // 
            this.iNVOICEBindingSource.DataMember = "INVOICE";
            this.iNVOICEBindingSource.DataSource = this.personalFinancesDataSet;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Location = new System.Drawing.Point(541, 288);
            this.button3.Margin = new System.Windows.Forms.Padding(2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(82, 24);
            this.button3.TabIndex = 13;
            this.button3.Text = "Анулиране";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Location = new System.Drawing.Point(479, 56);
            this.button4.Margin = new System.Windows.Forms.Padding(2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(84, 27);
            this.button4.TabIndex = 14;
            this.button4.Text = "Търсене";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // pARTNERBindingSource
            // 
            this.pARTNERBindingSource.DataMember = "PARTNER";
            this.pARTNERBindingSource.DataSource = this.personalFinancesDataSet;
            // 
            // pARTNERTableAdapter
            // 
            this.pARTNERTableAdapter.ClearBeforeFill = true;
            // 
            // iNVOICETableAdapter
            // 
            this.iNVOICETableAdapter.ClearBeforeFill = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(101, 24);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(348, 20);
            this.textBox1.TabIndex = 15;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            this.textBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(479, 17);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(84, 27);
            this.button1.TabIndex = 16;
            this.button1.Text = "Търсене";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // Document
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.dateTimePicker2);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Document";
            this.Size = new System.Drawing.Size(822, 348);
            this.Load += new System.EventHandler(this.Document_Load);
            ((System.ComponentModel.ISupportInitialize)(this.iNVOICETYPEBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.personalFinancesDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iNVOICEBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pARTNERBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.BindingSource iNVOICETYPEBindingSource;
        private PersonalFinancesDataSet personalFinancesDataSet;
        private System.Windows.Forms.BindingSource pARTNERBindingSource;
        private PersonalFinancesDataSetTableAdapters.PARTNERTableAdapter pARTNERTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iNVOICEIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pARTNERIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iNVOCIENODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iNVOCIEDATEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iNVOICETYPEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iNVOICEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iNVOICESTATUSDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iNVOICEVALUEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iNVOICENOTEDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource iNVOICEBindingSource;
        private PersonalFinancesDataSetTableAdapters.INVOICETableAdapter iNVOICETableAdapter;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button1;
    }
}
