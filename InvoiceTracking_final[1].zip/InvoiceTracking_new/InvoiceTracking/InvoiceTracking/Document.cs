﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace InvoiceTracking
{
    public partial class Document : UserControl
    {
        public static SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-3U1HHPM\SQLEXPRESS;Initial Catalog=PersonalFinances;Integrated Security=True");
        SqlCommand cmd;
       
        public Document()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dateTimePicker1.ResetText();
            dateTimePicker2.ResetText();
            iNVOICETableAdapter.Fill(this.personalFinancesDataSet.INVOICE);





        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                this.Validate();
                DialogResult dialogResult = MessageBox.Show("Сугурни ли сте, че искате да направите промените", " ", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    iNVOICETableAdapter.Update(this.personalFinancesDataSet.INVOICE);
                    MessageBox.Show("Успешно редактиране", "Успешно");
                }
                else if (dialogResult == DialogResult.No)
                {
                    MessageBox.Show("Неуспешно премахване", "Неуспешно ");
                    iNVOICETableAdapter.Fill(this.personalFinancesDataSet.INVOICE);


                }

            }
            catch
            {
                MessageBox.Show("Неуспешно премахване", "Неуспешно ");
            }
        }

        private void ShowData(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("DeleteDocument", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            //SqlParameter[] parm = new SqlParameter[1];
            SqlParameter parm = new SqlParameter("@INVOICE_ID", SqlDbType.Int);
            parm.Value = int.Parse(dataGridView1.SelectedRows[0].Cells[0].Value.ToString());
            cmd.Parameters.Add(parm);
            SqlParameter parm1 = new SqlParameter("@inv", SqlDbType.Int);
            parm1.Direction = ParameterDirection.Output;
            cmd.Parameters.Add(parm1);
            try
            {
                conn.Open();
                SqlDataReader r = cmd.ExecuteReader();
                int result = (Int32)cmd.Parameters["@inv"].Value;
                if (result != 0)
                {
                    MessageBox.Show("Записът бе успешно премахнат");
                }
                else
                {
                    MessageBox.Show("Не е намерен запис");
                }
            }
            catch
            {
            }
            iNVOICETableAdapter.Fill(this.personalFinancesDataSet.INVOICE);

        }

        private void button4_Click(object sender, EventArgs e)
        {
            conn.Open();
            SqlDataAdapter search= new SqlDataAdapter("SELECT * from INVOICE WHERE INVOCIE_DATE between '"+dateTimePicker1.Value.ToString("MM/dd/yyyy")+"' and '"+dateTimePicker2.Value.ToString("MM/dd/yyyy")+"'",conn);
            DataSet ds = new DataSet();
            search.Fill(ds, "INVOICE");
            dataGridView1.DataSource = ds.Tables["INVOICE"];
            conn.Close();
         }

        private void Document_Load(object sender, EventArgs e)
        {
            iNVOICETableAdapter.Fill(this.personalFinancesDataSet.INVOICE);
            //dataGridView1.Refresh();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            
            
            
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            BindingSource bs = new BindingSource();
            bs.DataSource = dataGridView1.DataSource;
            bs.Filter = dataGridView1.Columns[0].HeaderText.ToString() + "LIKE '%" + textBox1 + "%'";
            dataGridView1.DataSource = bs;
        }
    }
}
