﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InvoiceTracking
{
    public partial class DocReports : UserControl
    {
        public DocReports()
        {
            InitializeComponent();
        }

        private void DocReports_Load(object sender, EventArgs e)
        {
            iNVOICETableAdapter.Fill(this.personalFinancesDataSet.INVOICE);
            pARTNERTableAdapter.Fill(this.personalFinancesDataSet.PARTNER);
            invoicE_TYPETableAdapter1.Fill(this.personalFinancesDataSet.INVOICE_TYPE);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
           
            comboBox1.ResetText();
            comboBox3.ResetText();
            comboBox4.ResetText();
            dateTimePicker1.ResetText();
            dateTimePicker2.ResetText();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                iNVOICEBindingSource.Filter = "SELECT * FROM INVOICE " +
                      " WHERE INVOICE_TYPE = " + comboBox1.SelectedValue.ToString()
                     + " and PARTNER_ID = " + comboBox3.SelectedValue.ToString()
                     + " and INVOICE_STATUS like '%" + comboBox4.SelectedItem.ToString()
                     + "%' and INVOCIE_NO  like '%" + textBox1.Text
                     + "%' and INVOCIE_DATE between '" + dateTimePicker1.Value.ToString("MM/dd/yyyy")
                     + "' and '" + dateTimePicker2.Value.ToString("MM/dd/yyyy") + "'";
                
            }
            catch (Exception ex) { }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                iNVOICEBindingSource.Filter = "INVOICE_TYPE = " + comboBox1.SelectedValue.ToString()
                     + " and PARTNER_ID = " + comboBox3.SelectedValue.ToString()
                     + " and INVOICE_STATUS like '%" + comboBox4.SelectedItem.ToString()
                     + "%' and INVOCIE_NO  like '%" + textBox1.Text
                     + "%' and INVOCIE_DATE between '" + dateTimePicker1.Value.ToString("MM/dd/yyyy")
                     + "' and '" + dateTimePicker2.Value.ToString("MM/dd/yyyy") + "'";

            }
            catch (Exception ex) { }

        }
    }
}
