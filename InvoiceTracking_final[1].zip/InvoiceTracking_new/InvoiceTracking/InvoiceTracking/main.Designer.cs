﻿namespace InvoiceTracking
{
    partial class main
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.personalFinancesDataSet = new InvoiceTracking.PersonalFinancesDataSet();
            this.unpaindInvoiceBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.unpaindInvoiceTableAdapter = new InvoiceTracking.PersonalFinancesDataSetTableAdapters.UnpaindInvoiceTableAdapter();
            this.tableAdapterManager = new InvoiceTracking.PersonalFinancesDataSetTableAdapters.TableAdapterManager();
            this.unpaindInvoiceDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.personalFinancesDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unpaindInvoiceBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unpaindInvoiceDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(291, 144);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(171, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Просрочени фактури";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // personalFinancesDataSet
            // 
            this.personalFinancesDataSet.DataSetName = "PersonalFinancesDataSet";
            this.personalFinancesDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // unpaindInvoiceBindingSource
            // 
            this.unpaindInvoiceBindingSource.DataMember = "UnpaindInvoice";
            this.unpaindInvoiceBindingSource.DataSource = this.personalFinancesDataSet;
            // 
            // unpaindInvoiceTableAdapter
            // 
            this.unpaindInvoiceTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.Connection = null;
            this.tableAdapterManager.INVOICE_TYPETableAdapter = null;
            this.tableAdapterManager.INVOICETableAdapter = null;
            this.tableAdapterManager.PARTNERTableAdapter = null;
            this.tableAdapterManager.PAYMENTSTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = InvoiceTracking.PersonalFinancesDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // unpaindInvoiceDataGridView
            // 
            this.unpaindInvoiceDataGridView.AutoGenerateColumns = false;
            this.unpaindInvoiceDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.unpaindInvoiceDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.unpaindInvoiceDataGridView.DataSource = this.unpaindInvoiceBindingSource;
            this.unpaindInvoiceDataGridView.Location = new System.Drawing.Point(158, 189);
            this.unpaindInvoiceDataGridView.Name = "unpaindInvoiceDataGridView";
            this.unpaindInvoiceDataGridView.Size = new System.Drawing.Size(444, 117);
            this.unpaindInvoiceDataGridView.TabIndex = 3;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "INVOICE_ID";
            this.dataGridViewTextBoxColumn1.HeaderText = "№ на документа";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "PARTNER_NAME";
            this.dataGridViewTextBoxColumn2.HeaderText = "Име на контрагента";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "PARTNERT_FULLNAME";
            this.dataGridViewTextBoxColumn3.HeaderText = "Фирма";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "INVOICE_";
            this.dataGridViewTextBoxColumn4.HeaderText = "Платима до";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.SteelBlue;
            this.label2.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.label2.Location = new System.Drawing.Point(175, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(390, 55);
            this.label2.TabIndex = 4;
            this.label2.Text = "ДОБРЕ ДОШЛИ";
            // 
            // main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.label2);
            this.Controls.Add(this.unpaindInvoiceDataGridView);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "main";
            this.Size = new System.Drawing.Size(758, 348);
            this.Load += new System.EventHandler(this.main_Load);
            ((System.ComponentModel.ISupportInitialize)(this.personalFinancesDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unpaindInvoiceBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unpaindInvoiceDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private PersonalFinancesDataSet personalFinancesDataSet;
        private System.Windows.Forms.BindingSource unpaindInvoiceBindingSource;
        private PersonalFinancesDataSetTableAdapters.UnpaindInvoiceTableAdapter unpaindInvoiceTableAdapter;
        private PersonalFinancesDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView unpaindInvoiceDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.Label label2;
    }
}
