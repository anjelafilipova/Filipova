﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InvoiceTracking
{
    public partial class Payments : UserControl
    {
        public Payments()
        {
            InitializeComponent();
        }

        private void Payments_Load(object sender, EventArgs e)
        {
            paymentsTableAdapter1.Fill(this.personalFinancesDataSet.PAYMENTS);
            invoiceTableAdapter1.Fill(this.personalFinancesDataSet.INVOICE);
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            double a = 0;
            if (comboBox2.SelectedItem.ToString() == "$")
            {
                textBox2.Visible = true;
                a = Convert.ToDouble(textBox1.Text) * 1.59;
                textBox2.Text = a.ToString();
                comboBox3.Text = "USD";

            }
            else if (comboBox2.SelectedItem.ToString() == "€")
            {
                textBox2.Visible = true;
                a = Convert.ToDouble(textBox1.Text) * 1.95;
                textBox2.Text = a.ToString();
                comboBox3.Text = "EUR";

            }
            else
            {
                textBox2.Visible = false;
                comboBox3.Text = "BG";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            comboBox1.ResetText();
            comboBox2.ResetText();
            comboBox3.ResetText();
            textBox1.Clear();
            textBox2.Clear();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox2.Visible == true)
                {
                    paymentsTableAdapter1.Insert(
                    Convert.ToInt32(comboBox1.SelectedValue),
                    dateTimePicker1.Value,
                    Convert.ToDecimal(textBox2.Text));
                }
                else
                {
                    paymentsTableAdapter1.Insert(                   
                    Convert.ToInt32(comboBox1.SelectedValue),
                    dateTimePicker1.Value,
                    Convert.ToDecimal(textBox1.Text));

                }

                MessageBox.Show("", "Успешно добавяне");
            }
            catch
            {
                MessageBox.Show("", "Неуспешно добавяне");
            }
            comboBox1.ResetText();
            comboBox2.ResetText();
            comboBox3.ResetText();
            textBox1.Clear();
            textBox2.Clear();
            paymentsTableAdapter1.Fill(this.personalFinancesDataSet.PAYMENTS);
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_Validating(object sender, CancelEventArgs e)
        {
            if (comboBox1.SelectedIndex.ToString() == "")
            {
                errorProvider1.SetError(comboBox1, "Задължително поле за попълване");

            }
            else
            {
                errorProvider1.SetError(comboBox1, "");
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

            
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_Validating(object sender, CancelEventArgs e)
        {
            double a = Convert.ToDouble(textBox1.Text);
            if (a < 0)
            {
                errorProvider1.SetError(textBox1, "Само положителни стойности");

            }
            else
            {
                errorProvider1.SetError(textBox1, "");
            }
        }
    }
}
