﻿namespace InvoiceTracking
{
    partial class PartnerINFO
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.personalFinancesDataSet = new InvoiceTracking.PersonalFinancesDataSet();
            this.pARTNERBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pARTNERTableAdapter = new InvoiceTracking.PersonalFinancesDataSetTableAdapters.PARTNERTableAdapter();
            this.tableAdapterManager = new InvoiceTracking.PersonalFinancesDataSetTableAdapters.TableAdapterManager();
            this.iNVOICETableAdapter = new InvoiceTracking.PersonalFinancesDataSetTableAdapters.INVOICETableAdapter();
            this.iNVOICEBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.iNVOICEDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.personalFinancesDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pARTNERBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iNVOICEBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iNVOICEDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // personalFinancesDataSet
            // 
            this.personalFinancesDataSet.DataSetName = "PersonalFinancesDataSet";
            this.personalFinancesDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // pARTNERBindingSource
            // 
            this.pARTNERBindingSource.DataMember = "PARTNER";
            this.pARTNERBindingSource.DataSource = this.personalFinancesDataSet;
            // 
            // pARTNERTableAdapter
            // 
            this.pARTNERTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.INVOICE_TYPETableAdapter = null;
            this.tableAdapterManager.INVOICETableAdapter = this.iNVOICETableAdapter;
            this.tableAdapterManager.PARTNERTableAdapter = this.pARTNERTableAdapter;
            this.tableAdapterManager.PAYMENTSTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = InvoiceTracking.PersonalFinancesDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // iNVOICETableAdapter
            // 
            this.iNVOICETableAdapter.ClearBeforeFill = true;
            // 
            // iNVOICEBindingSource
            // 
            this.iNVOICEBindingSource.DataMember = "INVOICE";
            this.iNVOICEBindingSource.DataSource = this.personalFinancesDataSet;
            // 
            // iNVOICEDataGridView
            // 
            this.iNVOICEDataGridView.AutoGenerateColumns = false;
            this.iNVOICEDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.iNVOICEDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9});
            this.iNVOICEDataGridView.DataSource = this.iNVOICEBindingSource;
            this.iNVOICEDataGridView.Location = new System.Drawing.Point(-3, -2);
            this.iNVOICEDataGridView.Name = "iNVOICEDataGridView";
            this.iNVOICEDataGridView.Size = new System.Drawing.Size(688, 220);
            this.iNVOICEDataGridView.TabIndex = 20;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "INVOICE_ID";
            this.dataGridViewTextBoxColumn1.HeaderText = "INVOICE_ID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Visible = false;
            this.dataGridViewTextBoxColumn1.Width = 25;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "PARTNER_ID";
            this.dataGridViewTextBoxColumn2.HeaderText = "ID";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 25;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "INVOCIE_NO";
            this.dataGridViewTextBoxColumn3.HeaderText = "INVOCIE_NO";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "INVOCIE_DATE";
            this.dataGridViewTextBoxColumn4.HeaderText = "INVOCIE_DATE";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "INVOICE_TYPE";
            this.dataGridViewTextBoxColumn5.HeaderText = "INVOICE_TYPE";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "INVOICE_";
            this.dataGridViewTextBoxColumn6.HeaderText = "INVOICE_";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "INVOICE_STATUS";
            this.dataGridViewTextBoxColumn7.HeaderText = "INVOICE_STATUS";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "INVOICE_VALUE";
            this.dataGridViewTextBoxColumn8.HeaderText = "INVOICE_VALUE";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "INVOICE_NOTE";
            this.dataGridViewTextBoxColumn9.HeaderText = "INVOICE_NOTE";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // PartnerINFO
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(685, 216);
            this.Controls.Add(this.iNVOICEDataGridView);
            this.Name = "PartnerINFO";
            this.Text = "PartnerINFO";
            this.Load += new System.EventHandler(this.PartnerINFO_Load);
            ((System.ComponentModel.ISupportInitialize)(this.personalFinancesDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pARTNERBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iNVOICEBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iNVOICEDataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private PersonalFinancesDataSet personalFinancesDataSet;
        private System.Windows.Forms.BindingSource pARTNERBindingSource;
        private PersonalFinancesDataSetTableAdapters.PARTNERTableAdapter pARTNERTableAdapter;
        private PersonalFinancesDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private PersonalFinancesDataSetTableAdapters.INVOICETableAdapter iNVOICETableAdapter;
        private System.Windows.Forms.BindingSource iNVOICEBindingSource;
        private System.Windows.Forms.DataGridView iNVOICEDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
    }
}