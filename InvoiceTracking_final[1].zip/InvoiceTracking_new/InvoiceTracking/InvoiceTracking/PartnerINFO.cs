﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InvoiceTracking
{
    public partial class PartnerINFO : Form
    {
        public PartnerINFO()
        {
            InitializeComponent();
        }

        public PartnerINFO(int id)
        {
            partner_id = id;
            InitializeComponent();
        }

        private void iNVOICEBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.iNVOICEBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.personalFinancesDataSet);

        }

        private void pARTNERBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.pARTNERBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.personalFinancesDataSet);

        }
        int partner_id;
        private void PartnerINFO_Load(object sender, EventArgs e)
        {
            iNVOICEBindingSource.Filter = "PARTNER_ID= " + partner_id;
            //comboBox1.SelectedValue = partner_id;
            // TODO: This line of code loads data into the 'personalFinancesDataSet.INVOICE' table. You can move, or remove it, as needed.
            this.iNVOICETableAdapter.Fill(this.personalFinancesDataSet.INVOICE);
            // TODO: This line of code loads data into the 'personalFinancesDataSet.PARTNER' table. You can move, or remove it, as needed.
            this.pARTNERTableAdapter.Fill(this.personalFinancesDataSet.PARTNER);


        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
