﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InvoiceTracking
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
            textBox2.PasswordChar = '*';
            textBox2.MaxLength = 8;
        }

        private void button1_Click(object sender, EventArgs e)
        {
           string username = textBox1.Text.ToString();
            string pass = textBox2.Text.ToString();
            if (username=="manager"&& pass== "manager")
            {
                
                Form1 frm = new Form1();
                this.Hide();
                //frm.MdiParent = this;
                frm.ShowDialog();
                this.Close();
                


            }
            else
            {
                MessageBox.Show("Грешна парола или потебителско име");
            }
            
            
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Сигурни ли сте че искате да излезете от приложението", " ", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                Application.Exit();
            }
            else if (dialogResult == DialogResult.No)
            {

            }
        }
    }
}
