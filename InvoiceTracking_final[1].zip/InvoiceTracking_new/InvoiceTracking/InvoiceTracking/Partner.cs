﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace InvoiceTracking
{
    public partial class Partner : UserControl
    {
        public static SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-3U1HHPM\SQLEXPRESS;Initial Catalog=PersonalFinances;Integrated Security=True");
        SqlCommand cmd;
        public Partner()
        {

            InitializeComponent();
            
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            NewPartner np = new NewPartner();
            np.ShowDialog();
            pARTNERTableAdapter.Fill(this.personalFinancesDataSet.PARTNER);
        }
        private void Partner_Load(object sender, EventArgs e)
        {
            pARTNERTableAdapter.Fill(this.personalFinancesDataSet.PARTNER);
            dataGridView1.Refresh();
        }

        private void PartnerdataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void PartnerdataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            //try
            //{
            //    this.Validate();
            //    pARTNERTableAdapter.Update(this.personalFinancesDataSet.PARTNER);
            //    MessageBox.Show("", "Успешно редактиране");
            //}
            //catch
            //{
            //    MessageBox.Show("", "Неуспешно редактиране");
            //}
        }

        private void button3_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("DeletePartner", conn);
                cmd.CommandType = CommandType.StoredProcedure;
            //SqlParameter[] parm = new SqlParameter[1];
           SqlParameter parm = new SqlParameter("@PARTNER_ID", SqlDbType.Int);
            parm.Value = int.Parse(dataGridView1.SelectedRows[0].Cells[0].Value.ToString());
            cmd.Parameters.Add(parm);
            SqlParameter parm1 = new SqlParameter("@p_id", SqlDbType.Int);
            parm1.Direction = ParameterDirection.Output;
            cmd.Parameters.Add(parm1);
            try
            {
                conn.Open();
                SqlDataReader r = cmd.ExecuteReader();
                int result = (Int32)cmd.Parameters["@p_id"].Value;
                if (result != 0)
                {
                     MessageBox.Show ("Записът бе успешно премахнат");
                }
                else
                {
                    MessageBox.Show("Не е намерен запис");
                }
            }
            catch
            {
            }
            pARTNERTableAdapter.Fill(this.personalFinancesDataSet.PARTNER);






            //try
            //{
            //    //pARTNERTableAdapter.Delete(int.Parse(dataGridView1.SelectedRows[0].Cells[0].Value.ToString()));
            //    dataGridView1.DataSource = null;
            //    dataGridView1.DataSource = pARTNERTableAdapter.GetData();
            //    MessageBox.Show("", "Успешно премахване");
            //}
            //catch
            //{
            //    MessageBox.Show("", "Неуспешно премахване");
            //}
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                this.Validate();
                pARTNERTableAdapter.Update(this.personalFinancesDataSet.PARTNER);
                MessageBox.Show("Успешно редактиране", "Успешно");
            }
            catch
            {
                MessageBox.Show("неуспешно премахване", "Неуспешно ");
            }
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            PartnerINFO p_info = new PartnerINFO(Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value));
            p_info.Show();
        }

        private void dataGridView1_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
        }

        private void button4_Click(object sender, EventArgs e)
        {
            pARTNERBindingSource.Filter = "PARTNER_NAME like '%" + textBox1.Text + "%'";

        }
    }
}
