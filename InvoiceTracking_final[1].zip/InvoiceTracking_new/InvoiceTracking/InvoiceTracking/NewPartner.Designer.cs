﻿namespace InvoiceTracking
{
    partial class NewPartner
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PName_txt = new System.Windows.Forms.TextBox();
            this.PSName_txt = new System.Windows.Forms.TextBox();
            this.PFName_txt = new System.Windows.Forms.TextBox();
            this.FullName_txt = new System.Windows.Forms.TextBox();
            this.Egn_txt = new System.Windows.Forms.TextBox();
            this.PBulsat_txt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.PEmail_txt = new System.Windows.Forms.TextBox();
            this.PAdress_txt = new System.Windows.Forms.TextBox();
            this.PPhone_txt = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.partnerTableAdapter1 = new InvoiceTracking.PersonalFinancesDataSetTableAdapters.PARTNERTableAdapter();
            this.SuspendLayout();
            // 
            // PName_txt
            // 
            this.PName_txt.Location = new System.Drawing.Point(128, 42);
            this.PName_txt.Name = "PName_txt";
            this.PName_txt.Size = new System.Drawing.Size(166, 20);
            this.PName_txt.TabIndex = 0;
            // 
            // PSName_txt
            // 
            this.PSName_txt.Location = new System.Drawing.Point(129, 68);
            this.PSName_txt.Name = "PSName_txt";
            this.PSName_txt.Size = new System.Drawing.Size(166, 20);
            this.PSName_txt.TabIndex = 1;
            // 
            // PFName_txt
            // 
            this.PFName_txt.Location = new System.Drawing.Point(129, 94);
            this.PFName_txt.Name = "PFName_txt";
            this.PFName_txt.Size = new System.Drawing.Size(166, 20);
            this.PFName_txt.TabIndex = 2;
            // 
            // FullName_txt
            // 
            this.FullName_txt.Location = new System.Drawing.Point(129, 124);
            this.FullName_txt.Name = "FullName_txt";
            this.FullName_txt.Size = new System.Drawing.Size(166, 20);
            this.FullName_txt.TabIndex = 3;
            // 
            // Egn_txt
            // 
            this.Egn_txt.Location = new System.Drawing.Point(129, 150);
            this.Egn_txt.Name = "Egn_txt";
            this.Egn_txt.Size = new System.Drawing.Size(166, 20);
            this.Egn_txt.TabIndex = 4;
            // 
            // PBulsat_txt
            // 
            this.PBulsat_txt.Location = new System.Drawing.Point(129, 176);
            this.PBulsat_txt.Name = "PBulsat_txt";
            this.PBulsat_txt.Size = new System.Drawing.Size(166, 20);
            this.PBulsat_txt.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Име";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(32, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Презиме";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(32, 97);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Фамилия";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(32, 179);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Булсат";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(32, 153);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(28, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "ЕГН";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(32, 127);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Фирма";
            // 
            // PEmail_txt
            // 
            this.PEmail_txt.Location = new System.Drawing.Point(128, 202);
            this.PEmail_txt.Name = "PEmail_txt";
            this.PEmail_txt.Size = new System.Drawing.Size(166, 20);
            this.PEmail_txt.TabIndex = 12;
            // 
            // PAdress_txt
            // 
            this.PAdress_txt.Location = new System.Drawing.Point(129, 254);
            this.PAdress_txt.Multiline = true;
            this.PAdress_txt.Name = "PAdress_txt";
            this.PAdress_txt.Size = new System.Drawing.Size(166, 38);
            this.PAdress_txt.TabIndex = 13;
            // 
            // PPhone_txt
            // 
            this.PPhone_txt.Location = new System.Drawing.Point(128, 228);
            this.PPhone_txt.Name = "PPhone_txt";
            this.PPhone_txt.Size = new System.Drawing.Size(166, 20);
            this.PPhone_txt.TabIndex = 14;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(32, 205);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 13);
            this.label7.TabIndex = 15;
            this.label7.Text = "Имейл";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(32, 257);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(38, 13);
            this.label8.TabIndex = 16;
            this.label8.Text = "Адрес";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(32, 231);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(52, 13);
            this.label9.TabIndex = 17;
            this.label9.Text = "Телефон";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(249, 315);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 18;
            this.button1.Text = "Добави";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Location = new System.Drawing.Point(147, 315);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 19;
            this.button2.Text = "Изчисти";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(32, 20);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(26, 13);
            this.label10.TabIndex = 20;
            this.label10.Text = "Тип";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Физическо",
            "Юридическо"});
            this.comboBox1.Location = new System.Drawing.Point(129, 15);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(165, 21);
            this.comboBox1.TabIndex = 21;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // partnerTableAdapter1
            // 
            this.partnerTableAdapter1.ClearBeforeFill = true;
            // 
            // NewPartner
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(356, 363);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.PPhone_txt);
            this.Controls.Add(this.PAdress_txt);
            this.Controls.Add(this.PEmail_txt);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.PBulsat_txt);
            this.Controls.Add(this.Egn_txt);
            this.Controls.Add(this.FullName_txt);
            this.Controls.Add(this.PFName_txt);
            this.Controls.Add(this.PSName_txt);
            this.Controls.Add(this.PName_txt);
            this.Name = "NewPartner";
            this.Text = "NewPartner";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox PName_txt;
        private System.Windows.Forms.TextBox PSName_txt;
        private System.Windows.Forms.TextBox PFName_txt;
        private System.Windows.Forms.TextBox FullName_txt;
        private System.Windows.Forms.TextBox Egn_txt;
        private System.Windows.Forms.TextBox PBulsat_txt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox PEmail_txt;
        private System.Windows.Forms.TextBox PAdress_txt;
        private System.Windows.Forms.TextBox PPhone_txt;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox comboBox1;
        private PersonalFinancesDataSetTableAdapters.PARTNERTableAdapter partnerTableAdapter1;
    }
}