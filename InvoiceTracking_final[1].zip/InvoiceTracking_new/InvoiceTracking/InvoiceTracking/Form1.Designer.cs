﻿namespace InvoiceTracking
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.изходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.операцииToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.издаванеНаДокуметToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.редакцияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.документToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.патньориToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.плащанияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.регистриранеНаПлащанеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.просрочениФактуриToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.справкиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.издадениДокументиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.партньориToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.personalFinancesDataSet1 = new InvoiceTracking.PersonalFinancesDataSet();
            this.payments1 = new InvoiceTracking.Payments();
            this.partnerReports1 = new InvoiceTracking.PartnerReports();
            this.partner1 = new InvoiceTracking.Partner();
            this.newInvoice1 = new InvoiceTracking.NewInvoice();
            this.document1 = new InvoiceTracking.Document();
            this.docReports1 = new InvoiceTracking.DocReports();
            this.main1 = new InvoiceTracking.main();
            this.panel1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.personalFinancesDataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.button6);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.menuStrip1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(819, 72);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.AliceBlue;
            this.label1.Location = new System.Drawing.Point(433, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 20);
            this.label1.TabIndex = 8;
            this.label1.Text = "НАЧАЛО";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Transparent;
            this.button6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button6.BackgroundImage")));
            this.button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.button6.Location = new System.Drawing.Point(236, 31);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(41, 33);
            this.button6.TabIndex = 7;
            this.toolTip1.SetToolTip(this.button6, "Регистриране на плащане");
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Transparent;
            this.button5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button5.BackgroundImage")));
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.button5.Location = new System.Drawing.Point(734, 30);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(41, 33);
            this.button5.TabIndex = 6;
            this.toolTip1.SetToolTip(this.button5, "Изход");
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Transparent;
            this.button4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button4.BackgroundImage")));
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.button4.Location = new System.Drawing.Point(180, 31);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(41, 33);
            this.button4.TabIndex = 5;
            this.toolTip1.SetToolTip(this.button4, "Документи");
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Transparent;
            this.button3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button3.BackgroundImage")));
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.button3.Location = new System.Drawing.Point(121, 31);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(41, 33);
            this.button3.TabIndex = 4;
            this.toolTip1.SetToolTip(this.button3, "Издаване на документи");
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button2.BackgroundImage")));
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.button2.Location = new System.Drawing.Point(64, 31);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(41, 33);
            this.button2.TabIndex = 3;
            this.toolTip1.SetToolTip(this.button2, "Партньори");
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.button1.Location = new System.Drawing.Point(16, 30);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(36, 33);
            this.button1.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button1, "Начало");
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.операцииToolStripMenuItem,
            this.редакцияToolStripMenuItem,
            this.плащанияToolStripMenuItem,
            this.справкиToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 1, 0, 1);
            this.menuStrip1.Size = new System.Drawing.Size(819, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.изходToolStripMenuItem});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(48, 22);
            this.файлToolStripMenuItem.Text = "Файл";
            // 
            // изходToolStripMenuItem
            // 
            this.изходToolStripMenuItem.Name = "изходToolStripMenuItem";
            this.изходToolStripMenuItem.Size = new System.Drawing.Size(106, 22);
            this.изходToolStripMenuItem.Text = "Изход";
            this.изходToolStripMenuItem.Click += new System.EventHandler(this.изходToolStripMenuItem_Click);
            // 
            // операцииToolStripMenuItem
            // 
            this.операцииToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.издаванеНаДокуметToolStripMenuItem});
            this.операцииToolStripMenuItem.Name = "операцииToolStripMenuItem";
            this.операцииToolStripMenuItem.Size = new System.Drawing.Size(75, 22);
            this.операцииToolStripMenuItem.Text = "Операции";
            // 
            // издаванеНаДокуметToolStripMenuItem
            // 
            this.издаванеНаДокуметToolStripMenuItem.Name = "издаванеНаДокуметToolStripMenuItem";
            this.издаванеНаДокуметToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.издаванеНаДокуметToolStripMenuItem.Text = "Издаване на докумет";
            this.издаванеНаДокуметToolStripMenuItem.Click += new System.EventHandler(this.издаванеНаДокуметToolStripMenuItem_Click);
            // 
            // редакцияToolStripMenuItem
            // 
            this.редакцияToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.документToolStripMenuItem,
            this.патньориToolStripMenuItem});
            this.редакцияToolStripMenuItem.Name = "редакцияToolStripMenuItem";
            this.редакцияToolStripMenuItem.Size = new System.Drawing.Size(70, 22);
            this.редакцияToolStripMenuItem.Text = "Редакция";
            // 
            // документToolStripMenuItem
            // 
            this.документToolStripMenuItem.Name = "документToolStripMenuItem";
            this.документToolStripMenuItem.Size = new System.Drawing.Size(135, 22);
            this.документToolStripMenuItem.Text = "Документи";
            this.документToolStripMenuItem.Click += new System.EventHandler(this.документToolStripMenuItem_Click);
            // 
            // патньориToolStripMenuItem
            // 
            this.патньориToolStripMenuItem.Name = "патньориToolStripMenuItem";
            this.патньориToolStripMenuItem.Size = new System.Drawing.Size(135, 22);
            this.патньориToolStripMenuItem.Text = "Патньори";
            this.патньориToolStripMenuItem.Click += new System.EventHandler(this.патньориToolStripMenuItem_Click);
            // 
            // плащанияToolStripMenuItem
            // 
            this.плащанияToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.регистриранеНаПлащанеToolStripMenuItem,
            this.просрочениФактуриToolStripMenuItem});
            this.плащанияToolStripMenuItem.Name = "плащанияToolStripMenuItem";
            this.плащанияToolStripMenuItem.Size = new System.Drawing.Size(78, 22);
            this.плащанияToolStripMenuItem.Text = "Плащания";
            // 
            // регистриранеНаПлащанеToolStripMenuItem
            // 
            this.регистриранеНаПлащанеToolStripMenuItem.Name = "регистриранеНаПлащанеToolStripMenuItem";
            this.регистриранеНаПлащанеToolStripMenuItem.Size = new System.Drawing.Size(222, 22);
            this.регистриранеНаПлащанеToolStripMenuItem.Text = "Регистриране на плащане ";
            this.регистриранеНаПлащанеToolStripMenuItem.Click += new System.EventHandler(this.регистриранеНаПлащанеToolStripMenuItem_Click);
            // 
            // просрочениФактуриToolStripMenuItem
            // 
            this.просрочениФактуриToolStripMenuItem.Name = "просрочениФактуриToolStripMenuItem";
            this.просрочениФактуриToolStripMenuItem.Size = new System.Drawing.Size(222, 22);
            this.просрочениФактуриToolStripMenuItem.Text = "Просрочени фактури ";
            this.просрочениФактуриToolStripMenuItem.Click += new System.EventHandler(this.просрочениФактуриToolStripMenuItem_Click);
            // 
            // справкиToolStripMenuItem
            // 
            this.справкиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.издадениДокументиToolStripMenuItem,
            this.партньориToolStripMenuItem});
            this.справкиToolStripMenuItem.Name = "справкиToolStripMenuItem";
            this.справкиToolStripMenuItem.Size = new System.Drawing.Size(69, 22);
            this.справкиToolStripMenuItem.Text = "Справки ";
            // 
            // издадениДокументиToolStripMenuItem
            // 
            this.издадениДокументиToolStripMenuItem.Name = "издадениДокументиToolStripMenuItem";
            this.издадениДокументиToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.издадениДокументиToolStripMenuItem.Text = "Издадени документи ";
            this.издадениДокументиToolStripMenuItem.Click += new System.EventHandler(this.издадениДокументиToolStripMenuItem_Click);
            // 
            // партньориToolStripMenuItem
            // 
            this.партньориToolStripMenuItem.Name = "партньориToolStripMenuItem";
            this.партньориToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.партньориToolStripMenuItem.Text = "Партньори";
            this.партньориToolStripMenuItem.Click += new System.EventHandler(this.партньориToolStripMenuItem_Click);
            // 
            // personalFinancesDataSet1
            // 
            this.personalFinancesDataSet1.DataSetName = "PersonalFinancesDataSet";
            this.personalFinancesDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // payments1
            // 
            this.payments1.Location = new System.Drawing.Point(0, 73);
            this.payments1.Margin = new System.Windows.Forms.Padding(2);
            this.payments1.Name = "payments1";
            this.payments1.Size = new System.Drawing.Size(819, 357);
            this.payments1.TabIndex = 7;
            this.payments1.Load += new System.EventHandler(this.payments1_Load_1);
            // 
            // partnerReports1
            // 
            this.partnerReports1.Location = new System.Drawing.Point(0, 73);
            this.partnerReports1.Margin = new System.Windows.Forms.Padding(2);
            this.partnerReports1.Name = "partnerReports1";
            this.partnerReports1.Size = new System.Drawing.Size(819, 357);
            this.partnerReports1.TabIndex = 6;
            // 
            // partner1
            // 
            this.partner1.Location = new System.Drawing.Point(2, 73);
            this.partner1.Margin = new System.Windows.Forms.Padding(2);
            this.partner1.Name = "partner1";
            this.partner1.Size = new System.Drawing.Size(817, 353);
            this.partner1.TabIndex = 5;
            // 
            // newInvoice1
            // 
            this.newInvoice1.Location = new System.Drawing.Point(2, 73);
            this.newInvoice1.Margin = new System.Windows.Forms.Padding(2);
            this.newInvoice1.Name = "newInvoice1";
            this.newInvoice1.Size = new System.Drawing.Size(817, 353);
            this.newInvoice1.TabIndex = 4;
            this.newInvoice1.Tag = "";
            // 
            // document1
            // 
            this.document1.Location = new System.Drawing.Point(0, 73);
            this.document1.Margin = new System.Windows.Forms.Padding(2);
            this.document1.Name = "document1";
            this.document1.Size = new System.Drawing.Size(819, 355);
            this.document1.TabIndex = 3;
            // 
            // docReports1
            // 
            this.docReports1.Location = new System.Drawing.Point(0, 73);
            this.docReports1.Margin = new System.Windows.Forms.Padding(2);
            this.docReports1.Name = "docReports1";
            this.docReports1.Size = new System.Drawing.Size(819, 357);
            this.docReports1.TabIndex = 2;
            // 
            // main1
            // 
            this.main1.Location = new System.Drawing.Point(2, 73);
            this.main1.Margin = new System.Windows.Forms.Padding(1);
            this.main1.Name = "main1";
            this.main1.Size = new System.Drawing.Size(817, 357);
            this.main1.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(819, 429);
            this.Controls.Add(this.payments1);
            this.Controls.Add(this.partnerReports1);
            this.Controls.Add(this.partner1);
            this.Controls.Add(this.newInvoice1);
            this.Controls.Add(this.document1);
            this.Controls.Add(this.docReports1);
            this.Controls.Add(this.main1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Invoice Tracking";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.personalFinancesDataSet1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem изходToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem операцииToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem издаванеНаДокуметToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem редакцияToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem документToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem патньориToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem справкиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem издадениДокументиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem партньориToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem плащанияToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem регистриранеНаПлащанеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem просрочениФактуриToolStripMenuItem;
        private main main1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private DocReports docReports1;
        private Document document1;
        private NewInvoice newInvoice1;
        private Partner partner1;
        private PartnerReports partnerReports1;
        private Payments payments1;
        private PersonalFinancesDataSet personalFinancesDataSet1;
        private System.Windows.Forms.Label label1;
    }
}

