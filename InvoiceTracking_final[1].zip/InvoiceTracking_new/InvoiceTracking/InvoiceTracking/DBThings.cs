﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InvoiceTracking
{
    class DBThings
    {
        //public static SqlConnection CreateConnection()
        //{
        //    SqlConnection conn = new SqlConnection();
        //    conn.ConnectionString = @"Data Source=DESKTOP-3U1HHPM\SQLEXPRESS;Initial Catalog=Sales;IntegratedSecurity=True";
        //    return conn;
        //}
        //public static string DeleteSale(int parid)
        //{
        //    string resultMessage = "";
        //    SqlConnection con = CreateConnection();
        //    using (con)
        //    {

        //    }


        //}

    }
}
