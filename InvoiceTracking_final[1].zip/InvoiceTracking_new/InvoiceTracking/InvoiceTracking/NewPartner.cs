﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;

namespace InvoiceTracking
{
    public partial class NewPartner : Form
    {
        //public static SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-3U1HHPM\SQLEXPRESS;Initial Catalog=PersonalFinances;Integrated Security=True");

        public NewPartner()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            try
            {
                partnerTableAdapter1.Insert(PName_txt.Text, PSName_txt.Text, PFName_txt.Text, FullName_txt.Text, Egn_txt.Text, PBulsat_txt.Text, PEmail_txt.Text, PPhone_txt.Text, PAdress_txt.Text);
                MessageBox.Show("", "Успешно добавяне");
            }
            catch
            {
                MessageBox.Show("", "Неуспешно добавяне");
            }
            this.Close();
















        }

        private void button2_Click(object sender, EventArgs e)
        {
            comboBox1.ResetText();
            PFName_txt.Clear();
            PName_txt.Clear();
            PSName_txt.Clear();
            FullName_txt.Clear();
            Egn_txt.Clear();
            PBulsat_txt.Clear();
            PPhone_txt.Clear();
            PAdress_txt.Clear();
            PEmail_txt.Clear();
            FullName_txt.Enabled = true;
            PBulsat_txt.Enabled = true;
            PFName_txt.Enabled = true;
            PSName_txt.Enabled = true;
            PName_txt.Enabled = true;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem.ToString() == "Физическо")
            {
                FullName_txt.Enabled = false;
                PBulsat_txt.Enabled = false;
            }
            else if (comboBox1.SelectedItem.ToString() == "Юридическо")
            {
                FullName_txt.Enabled = true;
                PBulsat_txt.Enabled = true;
                PFName_txt.Enabled = false;
                PSName_txt.Enabled = false;
                PName_txt.Enabled = false;

            }
           
            
        }
    }
}
