﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InvoiceTracking
{
    public partial class PartnerReports : UserControl
    {
        public PartnerReports()
        {
            InitializeComponent();
        }

        private void PartnerReports_Load(object sender, EventArgs e)
        {
            pARTNERTableAdapter.Fill(this.personalFinancesDataSet.PARTNER);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
        }
        
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem.ToString() == "Физическо")
            {
                textBox2.Enabled = false;
                textBox3.Enabled = false;
            }
            else if (comboBox1.SelectedItem.ToString() == "Юридическо")
            {
                textBox2.Enabled = true;
                textBox3.Enabled = true;
                textBox4.Enabled = false;
                textBox5.Enabled = false;
                textBox6.Enabled = false;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                pARTNERBindingSource.Filter = "PARTNER_NAME like '%" + textBox4.Text
                    + "%' and PARTNER_SURNAME like '%" + textBox5.Text
                    + "%' and PARTNER_LASTNAME like '%" + textBox6.Text
                    + "%' and PARTNERT_FULLNAME like '%" + textBox3.Text
                    + "%' and PARTNER_EGN like '%" + textBox1.Text
                    + "%' and PARTNER_BULSTAT like '%" + textBox2.Text
                    + "%' and PARTNER_EMAIL like '%" + textBox7.Text + "%' ";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Грешка", "");
            }

        }
    }
}
